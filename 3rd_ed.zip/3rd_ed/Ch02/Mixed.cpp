// mixed.cpp
// shows mixed expressions
#include <iostream.h>
// using namespace std;

int main()
   {
   int count = 7;
   float avgWeight = 155.5F;

   double totalWeight = count * avgWeight;
   cout << "totalWeight=" << totalWeight << endl;
   return 0;
   }
