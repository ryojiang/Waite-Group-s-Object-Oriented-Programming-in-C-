// comments.cpp
// demonstrates comments
#include <iostream>             //preprocessor directive
using namespace std;            //"using" directive

int main()                      //function name "main"
   {                            //start function body
   cout << "Every age has a language of its own\n";  //statement
   return 0;                    //statement
   }                            //end function body