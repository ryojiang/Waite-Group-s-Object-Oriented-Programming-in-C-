#include <iostream>
using namespace std;

int main()
   {
   cout << "Every age has a language of its own\n";
   return 0;
   }